import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FilterComponent } from './filter/filter.component';
import { ListComponent } from './list/list.component';



@NgModule({
  declarations: [FilterComponent, ListComponent],
  imports: [
    CommonModule
  ],
  exports: [FilterComponent, ListComponent]
})
export class StudentModule { }
