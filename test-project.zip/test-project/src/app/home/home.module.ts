import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Section1Component } from './section1/section1.component';
import { Section2Component } from './section2/section2.component';
import { HomePageComponent } from './home-page/home-page.component';



@NgModule({
  declarations: [Section1Component, Section2Component, HomePageComponent],
  imports: [
    CommonModule
  ],
  exports: [Section1Component, Section2Component , HomePageComponent]
})
export class HomeModule { }
