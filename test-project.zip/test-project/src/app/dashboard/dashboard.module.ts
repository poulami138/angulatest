import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardMainComponent } from './dashboard-main/dashboard-main.component';
import { DbAboutComponent } from './dashboard-main/db-about/db-about.component';
import { DbServiceComponent } from './dashboard-main/db-service/db-service.component';
import { S1Component } from './dashboard-main/db-service/s1/s1.component';
import { from } from 'rxjs';


@NgModule({
  declarations: [DashboardMainComponent, DbAboutComponent, DbServiceComponent, S1Component],
  imports: [
    CommonModule,
    DashboardRoutingModule
  ],
  exports: [ DbAboutComponent, DbServiceComponent, S1Component]
})
export class DashboardModule { }
