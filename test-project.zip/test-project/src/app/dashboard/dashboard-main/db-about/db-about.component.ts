import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-about',
  templateUrl: './db-about.component.html',
  styleUrls: ['./db-about.component.scss']
})
export class DbAboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
