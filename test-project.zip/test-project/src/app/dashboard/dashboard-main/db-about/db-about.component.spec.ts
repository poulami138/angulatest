import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DbAboutComponent } from './db-about.component';

describe('DbAboutComponent', () => {
  let component: DbAboutComponent;
  let fixture: ComponentFixture<DbAboutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DbAboutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DbAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
