import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-db-service',
  templateUrl: './db-service.component.html',
  styleUrls: ['./db-service.component.scss']
})
export class DbServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
