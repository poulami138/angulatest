import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s1',
  templateUrl: './s1.component.html',
  styleUrls: ['./s1.component.scss']
})
export class S1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
