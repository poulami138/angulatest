import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DbServiceComponent } from './db-service.component';

describe('DbServiceComponent', () => {
  let component: DbServiceComponent;
  let fixture: ComponentFixture<DbServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DbServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DbServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
