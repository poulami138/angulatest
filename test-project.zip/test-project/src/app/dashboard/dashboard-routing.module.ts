import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardMainComponent } from './dashboard-main/dashboard-main.component'
import { from } from 'rxjs';
import { DbAboutComponent } from './dashboard-main/db-about/db-about.component';
import { DbServiceComponent } from './dashboard-main/db-service/db-service.component';
import { S1Component } from './dashboard-main/db-service/s1/s1.component';



const routes: Routes = [
  {
    path: '',
    component: DashboardMainComponent,
    children: [
      {
        path: 'db-about',
        component: DbAboutComponent
      },
      {
        path: 'db-service',
        component: DbServiceComponent
      },
      {
        path: 's1', 
        component: S1Component
      }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
